# component-symbols-test-printed

Held-out **test** crops rendered by `Synthetic Data/_tools/components_test.mjs` with a style regime
(fonts, stroke widths, paper tints, scales, 180 degree orientation, zoom, seeds) that never appears in
`component-symbols/`. Printed, not hand drawn. Evaluation only.

Crops: **198** under `images/test/` (3 per type, 66 types). Regenerate: `node components_test.mjs --per 3`.
